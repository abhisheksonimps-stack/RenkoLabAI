# Events

Domain event abstractions.