"""Signal models."""
