"""Market data source adapters."""
